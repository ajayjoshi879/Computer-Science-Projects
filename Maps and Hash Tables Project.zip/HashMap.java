/*
* An implementation of a hash table, using separate chaing as a resolution to collisions.
*
* Written by Andrew Qi
*/

import java.util.List;
import java.util.LinkedList;
import java.util.*;
import java.io.*;
import java.lang.Math;

public class HashMap<K, V> implements MapADT<K, V> {
	
	//Instance variable: table
	private LinkedList<TableEntry<K, V>>[] table;
	private final int INITIAL_SIZE = 101;
	private double load;

	/*
	* Constructor
	* Sets the initial size of the table to be 101
	* Creates a list in each spot of the table
	*/
	public HashMap() {
		//Initiate the table to a size of 101
		table = (LinkedList<TableEntry<K, V>>[]) new LinkedList[INITIAL_SIZE];

		//Initiate a linked list at each space in the table
		for (int i = 0; i < 101; i ++) {
			table[i] = new LinkedList<TableEntry<K, V>>();
		}

		this.load = 0;
	}

	/*
	* Allows a pair of values to be inputted into the HashMap as a TableEntry
	* If the given key already has a value, that value will be replaced and returned
	* 
	* @param key - the key of the data pair to be entered
	* @param val - the value of the data pair to be entered
	* @return - the value of the key that is modified / added
	*/
	public V put(K key, V val) {
		//Resize the table if the load factor is 1.0 or higher, i.e. when the table is full
		if (this.load >= 1.0) {
			System.out.println("Load factor reached 1.0 or higher. Resizing the table...");
			this.resize();
		}

		TableEntry<K, V> input = new TableEntry<K, V>(key, val);
		int index = this.hashCode(key);

		//Indicates whether the given parameters should be added as a new entry
		boolean exists = false;

		//Go through the table at the given index
		//If the given key exists, replace its value with the given value
		for (int i = 0; i < table[index].size(); i ++) {
			if (table[index].get(i).getKey().equals(key)) {
				exists = true;
				V temp = table[index].get(i).getValue();
				table[index].get(i).setValue(val);
				return temp;
			}
		}

		//Add the given key-value pair if the key does not yet exist
		if (exists == false) {
			table[index].add(input);
		}

		this.load = this.calcLoad();
		return val;
	}	

	/*
	* Gets the value of a given key from the HashMap
	* Throws a NoSuchElementException if the given key does not exist
	* 
	* @param key - the key whose value we are looking for
	* @return - the value associated with the given key
	*/
	public V get(K key) {
		int index = this.hashCode(key);

		//Go through the linked list at the given index of the table
		//Return the value of the given key
		for (int i = 0; i < table[index].size(); i ++) {
			if (table[index].get(i).getKey().equals(key)) {
				return table[index].get(i).getValue();
			}
		}

		throw new NoSuchElementException();
	}

	/*
	* Removes a given key-value pair from the HashMap
	* Throws a NoSuchElementException if the given key does not exist
	*
	* @param key - the key of the key-value pair to be removed
	* @return - the value of the key-value pair removed
	*/
	public V remove(K key) {
		int index = this.hashCode(key);

		//Go through the linked list at the given index
		//Remove the key-value pair of the given key and return its value
		for (int i = 0; i < table[index].size(); i ++) {
			if (table[index].get(i).getKey().equals(key)) {
				V temp = table[index].get(i).getValue();
				//does this work?
				table[index].remove(table[index].get(i));
				this.load = this.calcLoad();
				return temp;
			}
		}

		throw new NoSuchElementException();
	}

	/*
	* Tests whether the HashMap contains a given key.
	*
	* @param key - the key to search for
	* @return - a boolean representing whether the given key exists
	*/
	public boolean containsKey(K key) {
		int index = this.hashCode(key);

		//Find whether the key exists at the table index that it should be hashed at.
		for (int i = 0; i < table[index].size(); i ++) {
			if (table[index].get(i).getKey().equals(key)) {
				return true;
			}
		}

		return false;
	}

	/*
	* Tests whether the HashMap contains a given value.
	*
	* @param key - the value to search for
	* @return - a boolean representing whether the given value exists
	*/
	public boolean containsValue(V val) {
		//Go through every index of the table
		//Find whether the given value exists
		for (int i = 0; i < table.length; i ++) {
			LinkedList<TableEntry<K, V>> chain = table[i];
			for (int j = 0; j < chain.size(); j ++) {
				if (chain.get(j).getValue().equals(val)) {
					return true;
				}
			}
		}

		return false;
	}

	/*
	* A hash function that maps a given string to a specific position in the table.
	*
	* @param key - the key to hash
	* @return - the integer value of the key, based on the hash function
	*/
	public int hashCode(K key) {
		return Math.abs(key.hashCode() % table.length);
	}

	/*
	* Returns the table of the HashMap
	*/
	public LinkedList<TableEntry<K, V>>[] getTable() {
		return this.table;
	}

	/*
	* Calculates the ratio of entries in the HashMap to the total number
	* of spaces in the HashMap. A ratio of 1.0 or higher will signal the table to resize.
	*/
	private double calcLoad() {
		double occupied = 0;

		//Go through every index of the table, keeping count of
		//how many entries there are.
		for (int i = 0; i < table.length; i ++) {
			LinkedList<TableEntry<K, V>> chain = table[i];
			for (int j = 0; j < chain.size(); j ++) {
				if (chain.get(j).getKey().equals(null) == false) {
					occupied ++;
				}
			}
		}

		//Find and return the ratio of entries to table length
		double load = occupied / table.length;
		return load;
	}

	/*
	* Expands the HashMap's table when the load factor reaches 1.0.
	*/
	private void resize() {
		//Double the table's length and then find the nearest prime number
		int newSize = table.length * 2;
		while (this.isPrime(newSize) == false) {
			newSize ++;
		}

		//Create a new larger table, make the HashMap's table the newTable,
		//while keeping a reference to the old table.
		LinkedList<TableEntry<K, V>>[] newTable = (LinkedList<TableEntry<K, V>>[]) new LinkedList[newSize];
		LinkedList<TableEntry<K, V>>[] temp = table;
		table = newTable;

		//Initiate linked lists at each space in the newTable
		for (int i = 0; i < table.length; i ++) {
			table[i] = new LinkedList<TableEntry<K, V>>();
		}

		//Transfer all the data from the old table to the newTable
		for(int i = 0; i < temp.length; i ++) {
			LinkedList<TableEntry<K, V>> chain = temp[i];
			for (int j = 0; j < chain.size(); j ++) {
				if (chain.get(j).getKey().equals(null) == false) {
					K key = chain.get(j).getKey();
					V val = chain.get(j).getValue();
					this.add(key, val);
				}
			}
		}

		//Update the load factor
		this.load = this.calcLoad();
	}

	/*
	* Very similar to the put method, except does not call resize if the load factor is over 1.0.
	* Used within the resize method, to prevent recursive calls between resize and put.
	* Helps transfer all entries from old table to the new, larger table.
	*/
	private void add(K key, V val) {
		TableEntry<K, V> input = new TableEntry<K, V>(key, val);
		int index = this.hashCode(key);

		//Indicates whether the given parameters should be added as a new entry
		boolean exists = false;

		//Go through the table at the given index
		//If the given key exists, replace its value with the given value
		for (int i = 0; i < table[index].size(); i ++) {
			if (table[index].get(i).getKey().equals(key)) {
				exists = true;
				table[index].get(i).setValue(val);
				return;
			}
		}

		//Add the given key-value pair if the key does not yet exist
		if (exists == false) {
			table[index].add(input);
		}
	}

	/***********
   	* Determines whether a given integer is a prime number
   	* @param n the integer to test
   	* @return whether the integer is a prime
   	***********/
  	private boolean isPrime(int n) {
    	for(int i = 2; i < n; i++) {
      		if(n % i == 0) {
        		return false;
      		}
    	}
    	return true;
  	}
}