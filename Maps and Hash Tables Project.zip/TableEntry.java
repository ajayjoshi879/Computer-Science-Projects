/*
* A class that associates a given key to a given value,
* to create a key-value pair.
*
* Written by Andrew Qi
*/

public class TableEntry<S, T> {
	//Instance variables: a key and its value
	private S key;
	private T value;

	//Constructor takes two pieces of information: the key and its value
	public TableEntry(S newKey, T newVal) {
		this.key = newKey;
		this.value = newVal;
	}

	public S getKey() {
		return this.key;
	}

	public T getValue() {
		return this.value;
	}

	/*
	* Sets a TableEntry's key. If a key already exists, it is replaced
	* by the new key, and the replaced key is returned.
	*/
	public S setKey(S newKey) {
		if (this.key != null) {
			S temp = this.key;
			this.key = newKey;
			return temp;
		} else {
			this.key = newKey;
			return null;
		}
	}

	/*
	* Sets a TableEntry's value. If a value already exists, it is replaced
	* by the new value, and the replaced value is returned.
	*/
	public T setValue(T newVal) {
		if (this.value != null) {
			T temp = this.value;
			this.value = newVal;
			return temp;
		} else {
			this.value = newVal;
			return null;
		}
	}
}