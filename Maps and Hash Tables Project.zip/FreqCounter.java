/*
* A test class used to test the running of HashMap. 
* Scans a given file and counts the frequency of each word in the file
* using the HashMap.
*
* Written by Andrew Qi
*/

import java.util.Scanner;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class FreqCounter {
	
	public static void main(String[] args) {
		//initialize scanner from System.in (keyboard)
        //capture user input
        Scanner scanner1 = new Scanner(System.in);
        System.out.print("Enter the filename to count: ");
        String input = scanner1.nextLine();

        //Read all the words in given file
    	Scanner s = null;
    	try
    	{
    		s = new Scanner(new File(input));
    	}
    	catch(FileNotFoundException e)
    	{
    		System.out.println("Unable to find the given file");
    		System.exit(0);
    	}

        //Create new HashMap
    	HashMap<String, Integer> table = new HashMap<String, Integer>();

        //Add all the words in the given file into the HashMap,
        //while updating the respective counts of duplicate words.
    	while(s.hasNext())
    	{
    		String next = s.nextLine();
            String[] splitted = next.split(" ");
            for (int i = 0; i < splitted.length; i ++) {
                boolean exists = table.containsKey(splitted[i]);
                if (exists == true) {
                    Integer value = table.get(splitted[i]);
                    table.put(splitted[i], value + 1);
                } else {
                    table.put(splitted[i], 1);
                }
            }
    	}

        //printing everything in the HashMap
        LinkedList<TableEntry<String, Integer>>[] array = table.getTable();
    	for (int i = 0; i < array.length; i ++) {
    		LinkedList<TableEntry<String, Integer>> chain = array[i];
            if (chain.isEmpty() == false) {
                for (int j = 0; j < chain.size(); j ++) {
                    String word = chain.get(j).getKey();
                    int count = chain.get(j).getValue();
                    System.out.println(word + ": " + count);
                }
            }
    	}
	}	
}