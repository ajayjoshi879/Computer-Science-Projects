/*
An implementation of a stack using arrays.
*/

import java.util.EmptyStackException;

public class ArrayStack<T> implements StackADT<T> {

	//Initiate instance variables
	private T[] data;
	private int count;

	//Constructor for the stack, set to arbitrary size of 100
	public ArrayStack() {

		this.count = 0;
		this.data = (T[]) new Object[100];
	}

	//Allows new items of type T to be added to the top of the stack
	public void push(T info) {
		//If the stack is not full, simply add the new data
		if(this.count < this.data.length) {
			this.data[this.count] = info;
			this.count += 1;
		//If the stack is full, make a new stack twice the size of 
		//the current stack. Copy all data from current stack to new
		//stack, add the new data, and set the new stack to replace the current stack
		} else {
			T[] newStack = (T[]) new Object[2*this.count];
			for(int i = 0; i < this.count; i++) {
				newStack[i] = this.data[i];
			}
			this.data = newStack;
			this.data[this.count] = info;
			this.count += 1;
		}
	}

	//Allows the top item of the stack to be removed and returned, throws EmptyStackException if stack is empty
	public T pop() throws EmptyStackException {
		if(this.isEmpty() == false) {
			//Go back one space in the stack, as the top item is to be removed
			this.count -= 1;
			T item = this.data[this.count];
			this.data[this.count] = null;
			return item;
		} else {
			throw new EmptyStackException();
		}
	}

	//Returns the top item of the stack, throws EmptyStackException if stack is empty
	public T peek() throws EmptyStackException {
		if(this.isEmpty() == false) {
			//Retrace to the last item added to the stack
			T item = this.data[this.count - 1];
			return item;
		} else {
			throw new EmptyStackException();
		}
	}

	//Tests whether the stack is empty
	public boolean isEmpty() {
		//Test first index, since the first item, if any, would go here
		if(this.data[0] == null) {
			return true;
		}
		return false;
	}

	//Returns the number of items currently held in the stack
	public int size() {
		return this.count;
	}

	//Clears the entire stack
	public void clear() {
		while(this.isEmpty() == false) {
			this.pop();
		}
	}
}