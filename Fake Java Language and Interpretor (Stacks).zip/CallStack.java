/*
An implementation of a stack using linked nodes, which is used to simulate memory space.
*/

import java.util.EmptyStackException;

public class CallStack implements StackADT<Method> {
	
	//Initiate instance variables
	private int count;
	private Node<Method> first;
	private SimulationComponent sc;

	//Constructor, which takes a simulation component as a parameter
	public CallStack(SimulationComponent component) {
		this.count = 0;
		this.first = new Node();
		this.sc = component;
	}

	//Adds a new method to the stack
	public void push(Method methodName) {
		//Create a new node which contains the new method as its data
		Node<Method> temp = new Node(methodName);

		//Set the new node to point to the previous first node,
		//and set the new node as the current first node
		temp.setNext(this.first);
		this.first = temp;
		this.count ++;

		//Call to graphical stack, using the simulation component
		this.sc.addMethodToGraphicalStack(methodName);
		
	}

	//Removes the top method from a stack
	//Throws EmptyStackException if the stack is empty
	public Method pop() throws EmptyStackException {
		if(this.isEmpty()) {
			throw new EmptyStackException();
		} else {
			//Get the data from the first node, set start of linked stack to be the
			//node after the first node, thereby deleting the first node
			Method result = first.getData();
			this.first = first.getNext();
			this.count --;

			//Call to graphical stack, using simulation component
			this.sc.removeMethodFromGraphicalStack(result);

			return result;
		}
	}

	//Checks if the stack is empty
	public boolean isEmpty() {
		if(this.count == 0) {
			return true;
		}

		return false;
	}

	//Clears the stack
	public void clear() {
		this.first = null;
	}

	//Returns the number of items currently in the stack
	public int size() {
		return this.count;
	}

	//Returns the data at the top of the stack
	//Throws EmptyStackException if the stack is empty
	public Method peek() throws EmptyStackException {
		if(this.isEmpty()) {
			throw new EmptyStackException();
		} else {
			return this.first.getData();
		}
	}
}