/*
A program that spellchecks words given by the user, using a pre-existing list of words
as a guide as to the correct spelling of a large variety of words

Written by Andrew Qi
*/

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class SpellCheck {

    /*
    Main method
    */
	public static void main(String[] args) {
        StringComparator comparator = new StringComparator();
        
        //Create new ordered and unordered lists to store words later
    	UnorderedListADT<String> wordList = new LinkedUList<String>();
        OrderedListADT<String> wordOList = new ArrayOList<String>(comparator);

    	//Read all the words in wordlist file
    	Scanner s = null;
    	try {
            s = new Scanner(new File("wordlist"));
        } catch(FileNotFoundException e) {
            System.out.println("Unable to find wordlist file");
            System.exit(0);
        }

        //Add all the words in the wordlist, one by one, into an empty UnorderedList
        System.out.println("Loading wordlist into UnorderedList...");
        long uStartTime = System.nanoTime(); //Time the start time of the operation
    	while(s.hasNext())
    	{
    		wordList.add(s.nextLine(), 0);
    	}
        long uEndTime = System.nanoTime(); //Time the end time of the operation
        //Print total amount of time took for the operation
        System.out.println("Loaded (Took " + (uEndTime - uStartTime) + " nanoseconds)");       

        //Create a new scanner and read all the words in wordlist file again
        Scanner t = null;
        try {
            t = new Scanner(new File("wordlist"));
        } catch(FileNotFoundException e) {
            System.out.println("Unable to find wordlist file");
            System.exit(0);
        }

        //Add all the words in the wordlist, one by one, into an empty OrderedList
        System.out.println("Loading wordlist into OrderedList...");
        long oStartTime = System.nanoTime(); //Time start of operation
        while(t.hasNext())
        {
            wordOList.add(t.nextLine());
        }
        long oEndTime = System.nanoTime(); //Time end of operation
        //Print total duration of operation
        System.out.println("Loaded (Took " + (oEndTime - oStartTime) + " nanoseconds)");        

    	//Initialize scanner for user input and tell the user what to do
        Scanner scanner1 = new Scanner(System.in);
        System.out.print("Enter the word to spellcheck: ");
        
        //Use the nextLine method to read the inputted word from the user
        String input = scanner1.nextLine();

        //Continually prompt for words to chec
        //Exit if the user enters a blank line
        while(input.equals("") == false)
        {
            //See if the word inputted exists in our wordList
            //If so, it is spelled correctly, otherwise it is spelled incorrectly

            //The above process is repeated for the ordered and unordered list,
            //And their difference in time taken is compared
        	long uStart = System.nanoTime();
            boolean unorderedSpelling = wordList.contains(input);
            long uEnd = System.nanoTime();

            long oStart = System.nanoTime();
            boolean orderedSpelling = wordOList.contains(input);
            long oEnd = System.nanoTime();

            //If the word is spelled correctly, both searches will return true
        	if(unorderedSpelling == true && orderedSpelling == true) {
                System.out.println(input + " is spelled correctly. (Took unordered list " + (uEnd - uStart) + " nanoseconds.)");
                System.out.println(input + " is spelled correctly. (Took ordered list " + (oEnd - oStart) + " nanoseconds.)");
            } else {
                System.out.println(input + " is spelled incorrectly. (Took unordered list " + (uEnd - uStart) + " nanoseconds.)");
                System.out.println(input + " is spelled incorrectly (Took ordered list " + (oEnd - oStart) + " nanoseconds.)");
            }

            //Prompt the use for another word to spellcheck
        	System.out.print("Enter the word to spellcheck: ");
            input = scanner1.nextLine();
        	
        }

        //Exit message to the user
        System.out.println("Goodbye!");
        
  }
}