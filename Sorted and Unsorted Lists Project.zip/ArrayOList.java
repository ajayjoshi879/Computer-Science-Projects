/*
An array implementation of an ordered list.

Written by Andrew Qi
*/

import java.io.*;
import java.lang.*;
import java.util.*;

public class ArrayOList<T> implements OrderedListADT<T> {
	
	//Initiate instance variables
	private final static int NOT_FOUND = -1;
	private int rear;
	private T[] list;
	private Comparator<T> comparator;

	/******
	*Constructor
	*Comparator<T> parameter used for comparison of list items later
	*****/
	public ArrayOList(Comparator<T> compare) {
		this.rear = 0;
		this.list = (T[]) (new Object[100]);
		this.comparator = compare;
	}

	/***********************
   	* Remove the given item from the list
   	* @return The item that was removed
   	*************************/
	public T remove(T item) {
		//Find the index of the given element
		int index = 0;
		int location = NOT_FOUND;
		while(location == NOT_FOUND && index < this.rear) {
			if(this.comparator.compare(this.list[index], item) == 0) {
				location = index;
			}
			else {
				index ++;
			}
		}

		//Throw a warning if the given item is not found in the list
		if(location == NOT_FOUND) {
			throw new NoSuchElementException();
		}

		//Save the item to be removed to return later
		T result = list[location];
		this.rear --;

		//Shift the appropriate elements in the list after removing the given item
		for(int scan = location; scan < this.rear; scan ++) {
			this.list[scan] = this.list[scan + 1];
		}

		this.list[rear] = null;
		return result;
	}

	/***************
  	* Test whether the list contains the given item, using binary search
   	* @return true if the item is in the list
   	**********/
	public boolean contains(T item) {
		int low = 0;
		int high = this.rear - 1;

		//While the area of search has a length of at least 1
		while(high >= low) {
			int middle = (high + low) / 2;
			//The item is at the current index of the array
			if(this.comparator.compare(this.list[middle], item) == 0) {
				return true;
			//Item is before the current index of the array
			} else if(this.comparator.compare(this.list[middle], item) > 0) {
				high = middle - 1;
			//Item is after the current index of the array
			} else if(this.comparator.compare(this.list[middle], item) < 0) {
				low = middle + 1;
			}
		}

		return false;
	}

	/**************
	* Add an item into the ordered list, at the appropriate location
	*********/
	public void add(T item) {

		//Simply add the item if the list is empty and there is nothing to compare
		if(this.rear == 0) {
			this.list[0] = item;
			this.rear ++;
		} else {
			//Expand the array if it is full and transfer the contents to the new array
			if(this.rear == this.list.length) {
				T[] newArray = (T[]) (new Object[this.list.length * 2]);
				for(int i = 0; i < this.rear; i ++) {
					newArray[i] = this.list[i];
				}
				this.list = newArray;
			}

			//Find the index of where the given item is supposed to go
			int index = 0;
			for(int i = 0; i < this.rear; i ++) {
				if(this.comparator.compare(item, this.list[i]) <= 0) {
					index = i;
					break;
				} else if(i == (this.rear - 1)) {
					index = this.rear;
				}
			}
            
			//shift existing elements up one
			for(int shift = this.rear; shift > index; shift--) {
				this.list[shift] = this.list[shift - 1];
			}

			//insert element
			this.list[index] = item;
			this.rear ++;
		}
		
	}

	/*******************
   	* Get the item at the given index, starting at 0
   	* @return the item at that index
   	*******************/
	public T get(int index) {
		if(index >= this.rear) {
			throw new IndexOutOfBoundsException();
		}

		return this.list[index];
	}

	/******************
   	* Test whether the list is empty
   	* @return Whether the list is empty
   	********************/
	public boolean isEmpty() {
		if(this.list[0] == null) {
			return true;
		}

		return false;
	}

	/*********************
   	* Get the number of items in the list
   	* @return The number of items
   	*********************/
	public int size() {
		return this.rear;
	}		

	/**********************
   	* Clear the list
   	******************/
	public void clear() {
		this.list = (T[]) (new Object[100]);
		this.rear = 0;
	}
}