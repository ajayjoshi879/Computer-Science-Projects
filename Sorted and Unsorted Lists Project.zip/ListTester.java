/*
A class that tests the functioning of an array-implemented, sorted list

Written by Andrew Qi
*/

public class ListTester {

  /*
  Main method
  */
  public static void main(String[] args) {
    StringComparator comparator = new StringComparator();

    //Create a new list
    OrderedListADT<String> testList = new ArrayOList<String>(comparator);


    //Check the initial conditions of the list
    System.out.println("Printing list size: " + testList.size() + " (should be 0)");
    System.out.println("Printing list empty: " + testList.isEmpty() + " (should be true)");

    //Add elements to the list
    testList.add("a");
    testList.add("s");
    testList.add("d");
    testList.add("f");

    //Check that the elements are added to the list correctly
    //Check the isEmpty method of the list
    System.out.println("Printing list size: " + testList.size() + " (should be 4)");
    System.out.println("Printing list empty: " + testList.isEmpty() + " (should be false)");
    System.out.println("Printing the items in the list: " + testList.get(0) + testList.get(1) + testList.get(2) + testList.get(3) + " (should be adfs)");

    //Remove elements from the list
    testList.remove("a");
    testList.remove("f");

    //Check that the elements are correctly removed from the list
    //Check the contains method of the list
    System.out.println("Printing list size: " + testList.size() + " (should be 2)");
    System.out.println("Printing list contains letter f: " + testList.contains("f") + " (should be false)");
    System.out.println("Printing list contains d: " + testList.contains("d") + " (should be true)");
    System.out.println("Printing items in the list: " + testList.get(0) + testList.get(1) + " (should be ds)");

    //Add elements at indices where there are existing elements, to see if the list shifts
    //existing elements down as it is supposed to
    testList.add("z");
    testList.add("p");

    //Check that the above elements were added correctly
    //Check the get method of the list
    System.out.println("Printing 1st item: " + testList.get(0) + " (should be d)");
    System.out.println("Printing 4th item: " + testList.get(3) + " (should be z)");
    System.out.println("Printing list size: " + testList.size() + " (should be 4)");
    System.out.println("Printing the items in the list: " + testList.get(0) + testList.get(1) + testList.get(2) + testList.get(3) + " (should be dpsz)");

    //Test adding a new item at the end of a list
    testList.add("t");
    System.out.println("Printing items in the list: " + testList.get(0) + testList.get(1) + testList.get(2) + testList.get(3) + testList.get(4) + " (should be dpstz)");

    //Check that the clear method of the list works correctly
    testList.clear();
    System.out.println("Printing list empty: " + testList.isEmpty() + " (should be true)");

    //Check the expansion of the list, by adding more than 100 items into the list
    //by scanning the items of wordlist (>100 words) and adding them to the list
    Scanner t = null;
    try {
        t = new Scanner(new File("wordlist"));
    } catch(FileNotFoundException e) {
        System.out.println("Unable to find wordlist file");
        System.exit(0);
    }

    //Add all the words in the wordlist, one by one, into the empty testList
    System.out.println("Loading wordlist into OrderedList...");
    while(t.hasNext()) {
        testList.add(t.nextLine());
    }

    System.out.println("Successfully loaded " + testList.size() + "items into the list.");
    System.out.println("The 101th item is " + testList.get(101) + "; the list expands correctly when full.")
   
    //Test NoSuchElementFoundException
    System.out.println("Attempts to remove j from the list. Should give NoSuchElementFoundException error");
    testList.remove("j");
  }

}
