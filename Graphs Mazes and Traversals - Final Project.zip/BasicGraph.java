/*
* An implementation of a graph, which stores information about vertices and how vertices are
* connected to one another.
*
* Written by Andrew Qi and Eva Zhong
*/

import java.util.List;
import java.util.*;

public class BasicGraph<T> implements BasicGraphADT<T> {
	//instance variable
	private HashMap<T, Vertex<T>> adjList;

	//Constructor
	public BasicGraph() {
		adjList = new HashMap<T, Vertex<T>>();
	}

	/*******************
   	* Add a vertex to this graph with given label
   	* @return Whether the vertex was successfully added
   	********************/
  	public boolean addVertex(T vert) {
      //Create a new vertex for the given label and add it to the graph
  		Vertex<T> newVert = new Vertex<T>(vert);
  		adjList.put(vert, newVert);

  		return true;
  	}

  	/******************
   	* Add an edge to this graph between the two given labels
   	* @return Whether the edge was successfully added
   	********************/
  	public boolean addEdge(T beg, T end) {
  		//find the two vertices
      Vertex<T> first = adjList.get(beg);
  		Vertex<T> second = adjList.get(end);

      //add them to each other's neighbor list
  		first.addNeighbor(second);
  		second.addNeighbor(first);

  		return true;
  	}

  	/******************
   	* Tests whether a vertex exists in the graph
   	* @return Whether the vertex exists
   	********************/
  	public boolean hasVertex(T vert) {
  		if (adjList.containsKey(vert)) {
  			return true;
  		}

  		return false;
  	}

  	/******************
   	* Tests whether an edge exists in the graph
   	* @return Whether the edge exists
   	********************/
  	public boolean hasEdge(T beg, T end) {
      //get the two vertices' neighbor lists
  		Vertex<T> firstVert = adjList.get(beg);
  		Vertex<T> secondVert = adjList.get(end);

  		List<Vertex<T>> firstList = firstVert.getNeighbors();
  		List<Vertex<T>> secondList = secondVert.getNeighbors();

      //if both vertices exist in each other's neighbor list, an edge exists between them
  		if (firstList.contains(secondVert) && secondList.contains(firstVert)) {
  			return true;
  		}

  		return false;
  	}

  	/*****************
   	* Gets a list containing all the neighbors of a given vertex
   	* @return the neighbor list as a java List
   	*********************/
  	public List<Vertex<T>> getNeighbors(T vert) {
  		Vertex<T> first = adjList.get(vert);
  		return first.getNeighbors();
  	}

  	/****************************
   	* Gets the vertex object associated with the given label
   	* @return the vertex
   	************************/
  	public Vertex<T> getVertex(T lab) {
  		return adjList.get(lab);
  	}

  	/*****************
   	* Tests if the graph is empty
   	* @return Whether the graph is empty
   	*******************/
  	public boolean isEmpty() {
  		return adjList.isEmpty();
  	}

  	/********************
   	* Gets the number of vertices
   	* @return The number of vertices
   	*******************/
  	public int getNumVertices() {
  		return adjList.size();
  	}

  	/********************
   	* Gets the number of edges
   	* @return The number of edges
   	*********************/
  	public int getNumEdges() {
  		int count = 0;
  		//Assuming each undirected edge counts as two edges
      //count through all the vertices' neighbor lists
  		for (Map.Entry<T, Vertex<T>> entry : adjList.entrySet()) {
  			int size = entry.getValue().getNeighbors().size();
  			count += size;
  		}

  		return count;
  	}

  	/**************
   	* Clear all edges and vertices from the graph
   	********************/
  	public void clear() {
  		adjList.clear();
  	}

    /*
    * Converts the contents of all the vertices in a graph into string form
    */
  	public String toString() {
  		String vertices = "";
      //go through every vertex
  		for (Map.Entry<T, Vertex<T>> entry : adjList.entrySet()) {
        //add the vertex and its neighbors into a line of string
  			vertices += entry.getKey().toString() + " -> ";
  			List<Vertex<T>> neighbors = entry.getValue().getNeighbors();
  			for (int i = 0; i < neighbors.size(); i ++) {
  				Vertex<T> neighbor = neighbors.get(i);
  				vertices += neighbor.toString() + " ";
  			}
        //Add info for next vertex on a new line
  			vertices += "\n";
  		}

  		return vertices;
  	}

    //Basic test method used to test the implementation of the graph
  	public static void main(String[] args) {
 		BasicGraph<String> gr = new BasicGraph<String>(); 		

 		gr.addVertex("foo");
 		gr.addVertex("bar");
 		gr.addVertex("ninja");
 		gr.addVertex("robot");
 		gr.addVertex("baz");
 		gr.addEdge("foo", "bar");
 		gr.addEdge("foo", "baz");
 		gr.addEdge("foo", "ninja");
 		gr.addEdge("ninja", "robot");

 		System.out.println(gr.toString());
  	}
}