/*
* An implementation of a comparator class that helps compare vertices.
* Used in a priority queue to help sort vertices based on their distance.
*
* Written by Andrew Qi and Eva Zhong.
*/
import java.util.Comparator;

public class VertexComparator implements Comparator<Vertex<String>>{

  /*
  * Compare the distances of the two given vertices, 	returning an int
  * //that indicates whether vertex 1's distance is larger than, equal to, or smaller
  * than that of vertex 2
  */
  public int compare(Vertex<String> v1, Vertex<String> v2) {

  	double d1 = v1.getDistance();
  	double d2 = v2.getDistance();

  	if (d1 > d2) {
  		return 1;
  	} else if (d1 == d2) {
  		return 0;
  	} else {
  		return -1;
  	}
  }

}