/*
* An implementation of a stack, using an array.
*
*
* Written by Andrew Qi and Eva Zhong
*/

import java.util.EmptyStackException;


public class ArrayStack<T> implements StackADT<T> {

	// create the instance variables for the class
	private int count;
	private T[] data;

	// initialize the instance variables
	public ArrayStack() {
		this.count = 0;
		this.data = (T[]) new Object[10];
	}


	// Adds an item to the top of this stack.
	public void push(T item) {
		// if the stack is full, create a temporary stack that doubles the length, and copy
		// the items to the temporary stack
		if(this.count == this.data.length) {
			T[] temparr = (T[]) new Object[this.data.length*2];
			for(int i=0; i<this.data.length; i++) {
				temparr[i] = this.data[i];
			}

		// refer this.data to the new stack
		this.data = temparr;
		}

		this.data[this.count] = item;
		this.count++;
	}


	// Removes and returns the item from the top of this stack. 
	public T pop() {

		// if there is no item in the stack, throw an exception
		if (this.count == 0) {
			throw new EmptyStackException();
		}

		// create a variable to store the item to be returned
		T item = this.data[this.count-1];
		// remove the item from the stack
		this.data[this.count-1] = null;
		this.count--;
		return item;
	}


	// Returns the item on top of the stack, without removing it
	public T peek() {
		if (this.count == 0) {
			throw new EmptyStackException();
		}
		return this.data[this.count-1];
	}

	// Clears the stack by replacing the stack with a new, empty stack
	public void clear() {
		T temparr[] = (T[]) new Object[this.count];
		this.count = 0;
		this.data = temparr;
	}

	// Returns the number of items in the stack
	public int size() {
		return this.count;
	}

	// Returns true is the stack is empty
	public boolean isEmpty() {
		if (this.count == 0) {
			return true;
		} else {
			return false;
		}
	}
}