/*
* A class used to store edge weight information for the weighted maze algorithm.
* The class associates two vertex labels with a given weight between these vertices. 
*
* Written by Andrew Qi and Eva Zhong 
*/

public class Edge<T, Double> {

	//Instance variables
	private T label1;
	private T label2;
	private double weight;

	//Constructor takes all the necessary formation to store an edge weight
	public Edge(T first, T second, double number) {
		this.label1 = first;
		this.label2 = second;
		this.weight = number;
	}

	//Returns the label of the first vertex on the edge
	public T getLabel1() {
		return this.label1;
	}

	//Returns the label of the second vertex on the edge
	public T getLabel2() {
		return this.label2;
	}

	//Returns the weight between the two given vertices
	public double getWeight() {
		return this.weight;
	}
}
