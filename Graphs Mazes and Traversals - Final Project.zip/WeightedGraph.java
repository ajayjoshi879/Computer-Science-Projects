/*
* An implementation of a weighted graph, which saves information about vertices,
* their connections to each other, and the respective weights between each pair of vertices.
*
* Written by Andrew Qi and Eva Zhong.
*/

import java.util.List;
import java.util.*;

public class WeightedGraph<T> implements WeightedGraphADT<T> {
	//instance variables:
  //saves the vertices
	private HashMap<T, Vertex<T>> adjList;
  //saves objects of Edge class, which saves information about edge weights
  private LinkedList<Edge<T, Double>> edgeList;

	//Constructor
	public WeightedGraph() {
    //Initiate new data structures for storage
		adjList = new HashMap<T, Vertex<T>>();
    edgeList = new LinkedList<Edge<T, Double>>();
	}

	/*******************
   	* Add a vertex to this graph with given label
   	* @return Whether the vertex was successfully added
   	********************/
  	public boolean addVertex(T vert) {
      //create a new vertex and add it into the graph, with its associated label
  		Vertex<T> newVert = new Vertex<T>(vert);
  		adjList.put(vert, newVert);

  		return true;
  	}

  	/******************
   	* Tests whether a vertex exists in the graph
   	* @return Whether the vertex exists
   	********************/
  	public boolean hasVertex(T vert) {
  		if (adjList.containsKey(vert)) {
  			return true;
  		}

  		return false;
  	}

  	/******************
   	* Tests whether an edge exists in the graph
   	* @return Whether the edge exists
   	********************/
  	public boolean hasEdge(T beg, T end) {
      //get both vertices' neighbor lists
  		Vertex<T> firstVert = adjList.get(beg);
  		Vertex<T> secondVert = adjList.get(end);

  		List<Vertex<T>> firstList = firstVert.getNeighbors();
  		List<Vertex<T>> secondList = secondVert.getNeighbors();

      //if both vertices exist in each other's neighbor list then an egde exists between them
  		if (firstList.contains(secondVert) && secondList.contains(firstVert)) {
  			return true;
  		}

  		return false;
  	}

  	/*****************
   	* Gets a list containing all the neighbors of a given vertex
   	* @return the neighbor list as a java List
   	*********************/
  	public List<Vertex<T>> getNeighbors(T vert) {
  		Vertex<T> first = adjList.get(vert);
  		return first.getNeighbors();
  	}

  	/****************************
   	* Gets the vertex object associated with the given label
   	* @return the vertex
   	************************/
  	public Vertex<T> getVertex(T lab) {
  		return adjList.get(lab);
  	}

  	/*****************
   	* Tests if the graph is empty
   	* @return Whether the graph is empty
   	*******************/
  	public boolean isEmpty() {
  		return adjList.isEmpty();
  	}

  	/********************
   	* Gets the number of vertices
   	* @return The number of vertices
   	*******************/
  	public int getNumVertices() {
  		return adjList.size();
  	}

  	/********************
   	* Gets the number of edges
   	* @return The number of edges
   	*********************/
  	public int getNumEdges() {
  		int count = 0;
  		//Assuming each undirected edge counts as two edges
      //Count the number of neighbors in each vertex's neighbor list
  		for (Map.Entry<T, Vertex<T>> entry : adjList.entrySet()) {
  			int size = entry.getValue().getNeighbors().size();
  			count += size;
  		}

  		return count;
  	}

  	/**************
   	* Clear all edges and vertices from the graph
   	********************/
  	public void clear() {
  		adjList.clear();
  	}

    /******************
    * Add an edge to this graph between the two given labels
    * This addEdge method is the one required of BasicGraphADT
    * @return Whether the edge was successfully added
    ********************/
    public boolean addEdge(T beg, T end) {
      //add the two vertices to each other's neighbor lists
      adjList.get(beg).addNeighbor(adjList.get(end));
      adjList.get(end).addNeighbor(adjList.get(beg));

      return true; 
    }

    /******************
    * Add an edge to this graph between the two given labels with the given weight
    * This addEdge method is the one required of WeightedGraphADT
    * @return Whether the edge was successfully added
    ********************/
    public boolean addEdge(T beg, T end, double weight) {
      //add the vertices to each other's neighbor lists
      adjList.get(beg).addNeighbor(adjList.get(end));
      adjList.get(end).addNeighbor(adjList.get(beg));

      //create two new edge classes, for the two undirected edges between the two given vertices
      //each edge class saves the two given vertices along with their edge weight
      Edge<T, Double> newEdge = new Edge(beg, end, weight);
      Edge<T, Double> otherEdge = new Edge(end, beg, weight);

      //add these edges to the edgeList
      edgeList.add(newEdge);
      edgeList.add(otherEdge);

      return true; 
    }

    /******************
    * Gets the weight of the edge between two vertices
    * @return the weight, or Double.POSITIVE_INFINITY if no edge exists
    ********************/
    public double getEdgeWeight(T beg, T end) {
      //go through the edges list
      //find the edge that has the given two vertice labels and return the weight of that edge
      for (int i = 0; 0 < edgeList.size(); i ++) {
        Edge<T, Double> current = edgeList.get(i);
        if (current.getLabel1().equals(beg) && current.getLabel2().equals(end)) {
          return current.getWeight();
        }
      }

      double error = Double.POSITIVE_INFINITY;
      return error;
    }
}