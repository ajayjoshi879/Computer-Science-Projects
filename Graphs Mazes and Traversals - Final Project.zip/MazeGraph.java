import java.util.Scanner;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Comparator;

/*****************
 * This class reads in a maze (as created by Maze.java)
 * as a graph, then solves it, then prints out its solution
 *
 * To run it:
 * java MazeGraph [-w] mazefile.txt
 *
 * Use -w if you want to take weights into account
 *
 * Andy Exley
 *
 * Completed by Andrew Qi and Eva Zhong.
 */
public class MazeGraph {

  public static void main(String[] args) {
    String fname = null;
    String startvertex = null;
    String endvertex = null;
    boolean weighted = false;
    if(args.length < 3 || (args[0].equals("-w") && args.length < 4)) {
      System.err.println("Usage:\njava MazeGraph [-w] mazefile.txt start end");
      System.exit(1);
    } else if (args[0].equals("-w")) {
      fname = args[1];
      startvertex = args[2];
      endvertex = args[3];
      weighted = true;
    } else {
      fname = args[0];
      startvertex = args[1];
      endvertex = args[2];
    }
    
    if(!weighted) {
      BasicGraphADT<String> gmaze = loadMaze(fname);
      List<Vertex<String>> path1 = solveMazeDepthFirst(gmaze, startvertex, endvertex);
      System.out.println("Solution using DFS:");
      for(int i = 0; path1 != null && i < path1.size(); i++) {
        System.out.println(path1.get(i).getLabel());
      }

      // reload maze in case the graph needs to be reset
      BasicGraphADT<String> gmaze2 = loadMaze(fname);
      List<Vertex<String>> path2 = solveMazeBreadthFirst(gmaze2, startvertex, endvertex);
      System.out.println("Solution using BFS:");
      for(int i = 0; path2 != null && i < path2.size(); i++) {
        System.out.println(path2.get(i).getLabel());
      }
    } else {
      WeightedGraphADT<String> gmaze = loadWeightedMaze(fname);
      List<Vertex<String>> path3 = solveMaze(gmaze, startvertex, endvertex);
      System.out.println("Solution with least weight:");
      for(int i = 0; i < path3.size(); i++) {
        System.out.println(path3.get(i).getLabel());
      }
    }
  }

  /*********************
   * This method loads a maze from a given file with name fname
   *********************/
  public static BasicGraphADT<String> loadMaze(String fname) {
    BasicGraphADT<String> mymaze = new BasicGraph<String>(); 

    //Read all the words in given file
    Scanner s = null;
    try
    {
      s = new Scanner(new File(fname));
    }
    catch(FileNotFoundException e)
    {
      System.out.println("Unable to find the given file");
      System.exit(0);
    }

    //Initate a list to save each separate line of the maze (scanner)
    LinkedList<String[]> cells = new LinkedList<String[]>();

    //Load cells, by line, into a list
    while(s.hasNext()) {
      String next = s.nextLine();
      //split each line into an array, containing each maze cell in a separate index
      String[] strAr = next.split(" ");
      cells.add(strAr);
    }

    //Go through each maze cell, ignoring the first line that indicates dimension
    //int i indicates row number
    for (int i = 1; i < cells.size(); i ++) {
      String[] line = cells.get(i);
      //Go through each cell of the line (j = column)
      for (int j = 0; j < line.length; j ++) {
        //Add vertices, ignoring cells that end with a zero
        if (line[j].charAt(line[j].length() - 1) != '0') {
          mymaze.addVertex(line[j]);
        }
      }
    }

    //Add edges for each vertex
    for (int row = 1; row < cells.size(); row ++) {
      String[] line = cells.get(row);
      for (int col = 0; col < line.length; col ++) {
        String current = line[col];
        //only consider already existing vertices (non-zero ending)
        if (current.charAt(current.length() - 1) != '0') {
          //see if current cell connects to left cell
          if ((col - 1 >= 0) && line[col - 1].charAt(line[col - 1].length() - 1) != '0') {
            mymaze.addEdge(line[col - 1], line[col]);
          }
          //see if current cell connects to right cell
          if ((col + 1 < line.length) && line[col + 1].charAt(line[col + 1].length() - 1) != '0') {
            mymaze.addEdge(line[col + 1], line[col]);
          }

          //get the cells of the line above
          if (row - 1 > 0) {
            String[] prev = cells.get(row - 1);
            //see if current cell connects to cell above
            if (prev[col].charAt(prev[col].length() - 1) != '0') {
              mymaze.addEdge(prev[col], line[col]);
            }
          }
        
          //get the cells of the line below
          if (row + 1 < cells.size()) {
            String[] next = cells.get(row + 1);
            //see if current cell connects to cell below
            if (next[col].charAt(next[col].length() - 1) != '0') {
              mymaze.addEdge(next[col], line[col]);
            }
          }      
        }
      }
    }

    return mymaze;
  }

  /*********************
   * This method loads a maze from a given file with name fname as
   * a weighted graph
   *********************/
  public static WeightedGraphADT<String> loadWeightedMaze(String fname) {
    // build your maze based on the given file
    WeightedGraph<String> mymaze = new WeightedGraph<String>(); 

    //Read all the words in given file
    Scanner s = null;
    try
    {
      s = new Scanner(new File(fname));
    }
    catch(FileNotFoundException e)
    {
      System.out.println("Unable to find the given file");
      System.exit(0);
    }

    //Initate a list to save each separate line of the maze (scanner)
    LinkedList<String[]> cells = new LinkedList<String[]>();

    //Load cells, by line, into a list
    while(s.hasNext()) {
      String next = s.nextLine();
      //split each line into an array, containing each maze cell in a separate index
      String[] strAr = next.split(" ");
      cells.add(strAr);
    }

    //Go through each maze cell, ignoring the first line that indicates dimension
    //int i indicates row number
    for (int i = 1; i < cells.size(); i ++) {
      String[] line = cells.get(i);
      //Go through each cell in the row (j = column)
      for (int j = 0; j < line.length; j ++) {
        //Add vertices, ignoring cells that end with a zero
        if (line[j].charAt(line[j].length() - 1) != '0') {
          mymaze.addVertex(line[j]);
        }
      }
    }

    //Add edges for each vertex, while also adding the weight between
    //each pair of vertices added
    for (int row = 1; row < cells.size(); row ++) {
      String[] line = cells.get(row);
      for (int col = 0; col < line.length; col ++) {
        String current = line[col];
        //only consider already existing vertices (non-zero ending)
        if (current.charAt(current.length() - 1) != '0') {
          //the weight of the current vertex
          double fWeight = (double) (current.charAt(current.length() - 1) - '0');

          //see if current cell connects to left cell
          if ((col - 1 >= 0) && line[col - 1].charAt(line[col - 1].length() - 1) != '0') {
            //find the weight of this neigboring vertex
            double sWeight = (double) (line[col - 1].charAt(line[col - 1].length() - 1) - '0');
            //save the weight between these two vertices in an edge class
            mymaze.addEdge(line[col - 1], line[col], fWeight + sWeight);
          }
          //see if current cell connects to right cell
          if ((col + 1 < line.length) && line[col + 1].charAt(line[col + 1].length() - 1) != '0') {
            double sWeight = (double) (line[col + 1].charAt(line[col + 1].length() - 1) - '0');
            mymaze.addEdge(line[col + 1], line[col], fWeight + sWeight);
          }

          //get the cells of the line above
          if (row - 1 > 0) {
            String[] prev = cells.get(row - 1);
            //see if current cell connects to cell above
            if (prev[col].charAt(prev[col].length() - 1) != '0') {
              double sWeight = (double) (prev[col].charAt(prev[col].length() - 1) - '0');
              mymaze.addEdge(prev[col], line[col], fWeight + sWeight);
            }
          }
        
          //get the cells of the line below
          if (row + 1 < cells.size()) {
            String[] next = cells.get(row + 1);
            //see if current cell connects to cell below
            if (next[col].charAt(next[col].length() - 1) != '0') {
              double sWeight = (double) (next[col].charAt(next[col].length() - 1) - '0');
              mymaze.addEdge(next[col], line[col], fWeight + sWeight);
            }
          }      
        }
      }
    }

    return mymaze;
  }

  /******** 
   * This method should use a breadth-first traversal to find a path through the 
   * maze, then return that path.
   ******/
    public static List<Vertex<String>> solveMazeBreadthFirst(BasicGraphADT<String> maze, String startvert, String endvert) {
    // Use a breadth-first search to find a path through the maze

    //Initiate a queue for items yet to visit
    //Initiate a list for items already visited
    LinkedList<Vertex<String>> queue = new LinkedList<Vertex<String>>();
    List<Vertex<String>> visited = new ArrayList<Vertex<String>>();

    //add the starting vertex to the queue
    Vertex<String> startV = maze.getVertex(startvert);
    queue.add(startV);

    while (!queue.isEmpty()) {
      Vertex<String> currentVert = queue.remove();
      visited.add(currentVert);

      //Destination / end of maze reached
      if (currentVert.getLabel().equals(endvert)) {
        currentVert.getPath().add(currentVert);
        return currentVert.getPath();
      //Add all of the current vertex's neighbors (that aren't in queue or visited list) to the queue
      } else {
        List<Vertex<String>> neighborsList = currentVert.getNeighbors();
        for (int i = 0; i < neighborsList.size(); i ++) {
          Vertex<String> curNeighbor = neighborsList.get(i);
          //if unvisited / unmet before, keep track of how the maze got here,
          //give the neighbor that path, and add the neigbor to the queue
          if (!visited.contains(curNeighbor) && (!queue.contains(curNeighbor))) {
            //get the current vertex's path
            //copy all of it into a new path
            List<Vertex<String>> p = currentVert.getPath();
            List<Vertex<String>> newP = new LinkedList<Vertex<String>>();
            for (int j = 0; j < p.size(); j ++) {
              newP.add(p.get(j));
            }

            //add the current vertex to the new path copied
            //assign this new path to the neighbor
            newP.add(currentVert);
            curNeighbor.setPath(newP);
            queue.add(curNeighbor);
          }
        }
      }
    }
    return null;
  }
  
  /******** 
   * This method should use a depth-first traversal to find a path through the 
   * maze, then return that path.
   ******/
  public static List<Vertex<String>> solveMazeDepthFirst(BasicGraphADT<String> maze, String startvert, String endvert) {
    // Use a depth-first search to find a path through the maze

    //get the two starting vertices
    Vertex<String> startV = maze.getVertex(startvert);
    Vertex<String> endV = maze.getVertex(endvert);

    //Keep track of items-to-visit and visited-items.
    ArrayStack<Vertex<String>> s = new ArrayStack<Vertex<String>>();
    List<Vertex<String>> list = new ArrayList<Vertex<String>>();

    //add starting vertex to the to-visit stack
    s.push(startV);
    Vertex<String> currentvert = new Vertex<String>(startvert);

    while (s.isEmpty() == false) {
      currentvert = s.pop();
      //add the vertex to the visited list
      if (list.contains(currentvert) == false) {
        list.add(currentvert);
        currentvert.getLabel();
        //return the current vertex's path if it is the destination
        if (currentvert.getLabel().equals(endvert)) {
          currentvert.setPath(list);
          return currentvert.getPath();
        }
        //add all the current vertex's neighbors to the to-visit stack
        else {
          List<Vertex<String>> neighborList = currentvert.getNeighbors();
          for (int i = 0; i < neighborList.size(); i++) {
            Vertex<String> curNeighbor = neighborList.get(i);
            s.push(curNeighbor);
          }
        }
      }
    }
    return null;
  }

  /******** 
   * This method should use Dijkstra's algorithm to find the shortest cost path through the 
   * maze, then return that path.
   ******/
  public static List<Vertex<String>> solveMaze(WeightedGraphADT<String> maze, String startvert, String endvert) {
    // Use Dijkstra's algorithm to find a path through the maze
    
    //find the starting vertex
    //initiate a priority queue, with a vertex distance comparator, and add the vertex to the queue
    Vertex<String> startV = maze.getVertex(startvert);
    Comparator<Vertex<String>> comparator = new VertexComparator();
    PriorityQueue<Vertex<String>> pq = new PriorityQueue<Vertex<String>>(1000, comparator);
    pq.add(startV);

    while (pq.isEmpty() == false) {
      Vertex<String> currentVert = pq.poll();
      //return the current vertex's path if it is the destination
      if (currentVert.getLabel().equals(endvert)) {
        currentVert.getPath().add(currentVert);
        return currentVert.getPath();
      }
      else {
          //look through each of the current vertex's neighbors
          List<Vertex<String>> neighborsList = currentVert.getNeighbors();
          for (int i = 0; i < neighborsList.size(); i ++) {
            Vertex<String> curNeighbor = neighborsList.get(i);
            //if the current neighbpr already exists in the priority queue,
            //check if the new distance is shorter than the one existing
            if (pq.contains(curNeighbor)) {
                double originalDistance = curNeighbor.getDistance();
                double newDistance = currentVert.getDistance() + maze.getEdgeWeight(currentVert.getLabel(), curNeighbor.getLabel());
                //if the new distance is shorter, reset that vertex's path and distance to the shorter path
                if (newDistance < originalDistance) {
                  //reset to newer, shorter distance
                  curNeighbor.setDistance(newDistance);

                  //get current vertex's path, copy it, add the current vertex to the copied path
                  //and assign the new path to current neighbor
                  List<Vertex<String>> curVertPath = currentVert.getPath();
                  List<Vertex<String>> nPath = new LinkedList<Vertex<String>>();
                  for (int j = 0; j < curVertPath.size(); j ++) {
                    nPath.add(curVertPath.get(j));
                  }
                  nPath.add(currentVert);
                  curNeighbor.setPath(nPath);

                  //requeue current neigbor to ensure that its new distance is reflected in its position
                  //in the priority queue
                  pq.remove(curNeighbor);
                  pq.add(curNeighbor);
                } 
            }
            //the current neighbor does not yet exist in the priority queue
            else {
              //give current neighbor a distance 
              //(the current vertex's distance plus the weight between current vertex and current neighbor)
              curNeighbor.setDistance(currentVert.getDistance() + maze.getEdgeWeight(currentVert.getLabel(), curNeighbor.getLabel()));

              //get current vertex's path, copy it, add the current vertex to the copied path
              //and assign the new path to current neighbor
              List<Vertex<String>> curVertPath = currentVert.getPath();
              List<Vertex<String>> nPath = new LinkedList<Vertex<String>>();
              for (int j = 0; j < curVertPath.size(); j ++) {
                nPath.add(curVertPath.get(j));
              }
              nPath.add(currentVert);
              curNeighbor.setPath(nPath);

              //add the modified neighboring vertex into the priority queue
              pq.add(curNeighbor);
            }
          }

        }
    }
    return null;
  }
}
