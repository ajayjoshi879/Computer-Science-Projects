/*
A class that tests the functioning of an link-implemented, unsorted list

Written by Andrew Qi
*/

public class ListTester {

  /*
  Main method
  */
  public static void main(String[] args) {
    //Create a new list
    UnorderedListADT<String> testList = new LinkedUList<String>();

    //Check the initial conditions of the list
    System.out.println("Printing list size: " + testList.size() + " (should be 0)");
    System.out.println("Printing list empty: " + testList.isEmpty() + " (should be true)");

    //Add elements to the list
    testList.add("a", 0);
    testList.add("s", 1);
    testList.add("d", 2);
    testList.add("f", 3);

    //Check that the elements are added to the list correctly
    //Check the isEmpty method of the list
    System.out.println("Printing list size: " + testList.size() + " (should be 4)");
    System.out.println("Printing list empty: " + testList.isEmpty() + " (should be false)");

    //Remove elements from the list
    testList.remove("a");
    testList.remove("f");

    //Check that the elements are correctly removed from the list
    //Check the contains method of the list
    System.out.println("Printing list size: " + testList.size() + " (should be 2)");
    System.out.println("Printing list contains letter f: " + testList.contains("f") + " (should be false)");
    System.out.println("Printing list contains d: " + testList.contains("d") + " (should be true)");

    //Add elements at indices where there are existing elements, to see if the list shifts
    //existing elements down as it is supposed to
    testList.add("z", 0);
    testList.add("p", 2);

    //Check that the above elements were added correctly
    //Check the get method of the list
    System.out.println("Printing 1st item: " + testList.get(0) + " (should be z)");
    System.out.println("Printing 4th item: " + testList.get(3) + " (should be d)");
    System.out.println("Printing list size: " + testList.size() + " (should be 4)");

    //Test adding a new item at the end of a list
    testList.add("t", 4);
    System.out.println("Printing 5th item: " + testList.get(4) + " (should be t)");

    //Check that the clear method of the list works correctly
    testList.clear();
    System.out.println("Printing list empty: " + testList.isEmpty() + " (should be true)");

    //Test out of IndexOutOfBoundsException
    System.out.println("Attempts to get the 1th item of the list. Should give IndexOutOfBoundsException error");
    testList.get(0);
  }

}
