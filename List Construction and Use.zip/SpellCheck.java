/*
A program that spellchecks words given by the user, using a pre-existing list of words
as a guide as to the correct spelling of a large variety of words

Written by Andrew Qi
*/

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class SpellCheck {

    /*
    Main method
    */
	public static void main(String[] args) {
        //Create new empty list to store words later
    	UnorderedListADT<String> wordList = new LinkedUList<String>();

    	//Read all the words in wordlist file
    	Scanner s = null;
    	try
    	{
    		s = new Scanner(new File("wordlist"));
    	}
    	catch(FileNotFoundException e)
    	{
    		System.out.println("Unable to find wordlist file");
    		System.exit(0);
    	}

        //Add all the words in the wordlist, one by one, into an empty list
        int index = 0;
    	while(s.hasNext())
    	{
    		wordList.add(s.nextLine(), index);
            index ++;
    	}

    	//Initialize scanner for user input and tell the user what to do
        Scanner scanner1 = new Scanner(System.in);
        System.out.print("Enter the word to spellcheck: ");
        
        //Use the nextLine method to read the inputted word from the user
        String input = scanner1.nextLine();

        //Continually prompt for words to chec
        //Exit if the user enters a blank line
        while(input.equals("") == false)
        {
            //See if the word inputted exists in our wordList
            //If so, it is spelled correctly, otherwise it is spelled incorrectly
        	boolean spelling = wordList.contains(input);
        	if(spelling == true)
        	{
        		System.out.println(input + " is spelled correctly.");
        	} 
        	else
        	{
        		System.out.println(input + " is spelled incorrectly");
        	}

            //Prompt the use for another word to spellcheck
        	System.out.print("Enter the word to spellcheck: ");
            input = scanner1.nextLine();
        	
        }

        //Exit message to the user
        System.out.println("Goodbye!");
        
  }
}