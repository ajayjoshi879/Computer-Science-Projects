/*
An implementation of a node, to be used as part of a linked structure

Written by Andrew Qi
*/


public class Node<T> {
	
	//Initiate instance variables
	private T data;
	private Node<T> next;

	//Constructor that creates an empty node
	public Node() {
		this.data = null;
		this.next = null;
	}

	//Constructor that creates a new node with data in it
	public Node(T item) {
		this.data = item;
		this.next = null;
	}

	//Returns the node's data
	public T getData() {
		return this.data;
	}

	//Returns the next node that the current node current points to
	public Node<T> getNext () {
		return this.next;
	}

	//Sets the node's data
	public void setData(T item) {
		this.data = item;
	}

	//Sets the next node to which the current node points
	public void setNext(Node<T> item) {
		this.next = item;
	}
}