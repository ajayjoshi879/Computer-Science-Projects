/******************
 * A class that sorts file input
 *
 * java -s file.txt
 *   (for selection sort)
 *
 * java -m file.txt
 *   (for merge sort)
 *
 * java -r file.txt
 *   (for radix sort)
 * java -q file.txt
 *   (for quick sort)

 * @author Andy Exley
 * editted by Andrew Qi
 *****************/

import java.util.Arrays;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.io.File;

public class Sort {

  public static void main(String[] args) {
    if(args.length < 1) {
      usage();
    }
    
    char sorttype = 's';
    String filename = "";

    if(args[0].equals("-m")) {
      sorttype = 'm';
      if(args.length < 2) { usage(); }
      filename = args[1];
    } else if(args[0].equals("-s")) {
        sorttype = 's';
        if(args.length < 2) { usage(); }
        filename = args[1];
    } else if(args[0].equals("-r")) {
        sorttype = 'r';
        if(args.length < 2) { usage(); }
        filename = args[1];
    } else if(args[0].equals("-q")) {
        sorttype = 'q';
        if(args.length < 2) { usage(); }
        filename = args[1];
    } else {
        System.err.println("No sort specified, using selection sort");
        filename = args[0];
    }

    String[] arr = null;
    File tfile = new File(filename);
    try {
      ArrayList<String> list = new ArrayList<String>();
      Scanner scan = new Scanner(tfile);
      while(scan.hasNextLine()) {
        list.add(scan.nextLine());
      }
      arr = new String[list.size()];
      list.toArray(arr);
    } catch(FileNotFoundException e) {
      System.err.println("Error, cannot find file: " + filename);
      System.exit(1);
    }

    if(sorttype == 'm') {
      mergeSort(arr);
    } else if(sorttype == 's') {
      selectionSort(arr);
    } else if(sorttype == 'q') {
      quickSort(arr);
    } else if(sorttype == 'r') {
      radixSort(arr);
    }

    for(String line : arr) {
      System.out.println(line);
    }
  }

  /************
   * Prints out an error message explaining how to use this program
   * Then quits
   ****************/
  public static void usage() {
    System.err.println("Usage:\n\tjava Sort <sorttype> filename");
    System.err.println(" Where <sorttype> is:\n  -m Merge Sort\n -s Selection Sort");
    System.exit(1);
  }

  /*****
   * Merge sort helper method
   * @param arr The array to sort
   ******/
  public static void mergeSort(String[] arr) {
    mergeSortRec(arr, 0, arr.length - 1);
  }

  /*********
   * Merge sort recursive method
   * @param arr The array to sort
   * @param beg The beginning index to sort
   * @param end The end index to sort
   *********/
  private static void mergeSortRec(String[] arr, int beginIndex, int endIndex) {
    if(endIndex > beginIndex) {
      int a1length = (endIndex-beginIndex+1)/2;
      int a1end = beginIndex+a1length - 1;
      mergeSortRec(arr, beginIndex, beginIndex + (endIndex-beginIndex+1)/2 - 1);
      mergeSortRec(arr, a1end+1, endIndex);
      merge(arr,beginIndex,a1end,a1end+1,endIndex);
    } else {
      return;
    }
  }

  /****************
   * Merge step of merge sort algorithm
   * @param arr The array to sort
   * @param a1start Where the first sub-array begins
   * @param a1end Where the first sub-array ends
   * @param a2start Where the second sub-array begins
   * @param a2end Where the second sub-array ends
   **************/
  private static void merge(String[] arr, int a1start, int a1end, int a2start, int a2end) {
    String[] tmp = new String[a2end - a1start + 1]; 
    int tmpindex = 0;
    int start = a1start;
    while(a1start <= a1end && a2start <= a2end) {
      if(arr[a1start].compareTo(arr[a2start]) < 0) {
        tmp[tmpindex] = arr[a1start];
        a1start++;
      } else {
        tmp[tmpindex] = arr[a2start];
        a2start++;
      }
      tmpindex++;
    }
    // copy remaining items in array 1
    while(a1start <= a1end) {
      tmp[tmpindex] = arr[a1start];
      a1start++;
      tmpindex++;
    }
    // copy remaining items in array 2
    while(a2start <= a2end) {
      tmp[tmpindex] = arr[a2start];
      a2start++;
      tmpindex++;
    }
    // copy from temp array back into arr
    for(int i = start; i <= a2end; i++) {
      arr[i] = tmp[i - start];
    }
  }

  /*********
   * Selection sort method
   * @param arr The array to sort
   ******/
  public static void selectionSort(String[] arr) {
    for(int i = 0; i < arr.length; i++) {
      // find next smallest
      int smallestIndex = findNextSmallest(arr, i);
      
      // swap
      String tmp = arr[i];
      arr[i] = arr[smallestIndex];
      arr[smallestIndex] = tmp;
    }
  }

  /*************
   * Finds the index of the smallest item in arr, from n to arr.length-1
   * @param arr The array to search
   * @param n The index to start looking
   * @return The index of the smallest item
   **********/
  private static int findNextSmallest(String[] arr, int n) {
    int minindex = n;
    for(int i = n+1; i < arr.length; i++) {
      if(arr[i].compareTo(arr[minindex]) < 0) {
        minindex = i;
      }
    }
    return minindex;
  }

  /*
  * Sorts the specified array of objects using the quick sort algorithm
  * @param arr: the array to be sorted
  */
  public static void quickSort(String[] arr) {
    quickSortRecur(arr, 0, arr.length - 1);
  }

  /*
  * Recursively sorts a range of objects in the specified array using the quick sort algorithm.
  * @param arr: the array to be sorted
  * @param min: the minimum index in the range to be sorted
  * @param max: the maximum index in the range to be sorted
  */
  public static void quickSortRecur(String[] arr, int min, int max) {
    if(min < max) {
      //create first partitions
      int partitionIndex = partitionAndSort(arr, min, max);
      //sort left partition
      quickSortRecur(arr, min, partitionIndex - 1);
      //sort right partition
      quickSortRecur(arr, partitionIndex + 1, max);
    }
  }

  /*
  * Partitions an array and sorts the specified range of the array using quick sort algorithm.
  * @param arr: the array to be sorted
  * @param min: the minimum index in the range to be sorted
  * @param max: the maximum index in the range to be sorted
  * @return: returns the index of the partition element in the rearranged array
  */
  public static int partitionAndSort(String[] arr, int min, int max) {
    //index of the partition element
    int partition = (min + max) / 2;

    //stores the sorted version of the elements in the given range of the array
    String[] newArray = new String[max - min + 1];
    //temporarily stores items larger than the partition element
    String[] temp = new String[max - min + 1];

    //tracks where to add to in the temp array
    int large = 0;
    //tracks where to add to in newArray
    int small = 0;

    //go through all elements from min up to the partition element
    //copy small items into newArray in order of their occurence
    //copy larget item into temp array in order of their occurence
    for(int i = min; i < partition; i ++) {
      if(arr[i].compareTo(arr[partition]) > 0) {
        temp[large] = arr[i];
        large ++;
      } else {
        newArray[small] = arr[i];
        small ++;
      }
    }

    //go through all elements from partition element up to max
    //copy small items into newArray in order of their occurence
    //copy larget item into temp array in order of their occurence
    for(int j = partition + 1; j <= max; j++) {
      if(arr[j].compareTo(arr[partition]) > 0) {
        temp[large] = arr[j];
        large ++;
      } else {
        newArray[small] = arr[j];
        small ++;
      } 
    }

    //saves the number of items that were smaller than the partition element
    int partitionIndex = small; 
    //add the partition element to the newArray
    newArray[small] = arr[partition];
    small ++;

    //move all the items larger than the partition item, which were stored in temp array, into newArray
    for(int z = 0; z <= large - 1; z ++) {
      newArray[small] = temp[z];
      small ++;
    }

    //replace the segment of the original array with the sorted elements of newArray
    int index = 0;
    for(int k = min; k <= max; k ++) {
      arr[k] = newArray[index];
      index ++;
    }

    //returns where the partition element is found in the new reordered version of the orginal array
    int partitionLocation = min + partitionIndex;
    return partitionLocation;
  }

  /*
  * Uses radix sort to sort a given list of integers.
  *
  * @param arr: the array to be sorted
  */
  public static void radixSort(String[] arr) {
    //Initiate an array of 10 lists
    LinkedUList<Integer>[] digitLists = (LinkedUList<Integer>[]) (new LinkedUList[10]);

    //Adding a list into each position in the array; each list will correspond to a numerical digit
    for (int i = 0; i < 10; i ++) {
      digitLists[i] = new LinkedUList<Integer>();
    }

    //find the largest number (longest number of digits) in the arr given
    int maxLen = 0;
    for (int j = 0; j < arr.length; j++) {
      if (arr[j].length() > maxLen) {
        maxLen = arr[j].length();
      }
    }

    //sort the list
    int value;
    //go through once for each digit, within the range of the largest digit
    for(int position = 0; position <= maxLen; position ++) {
      //look at the nth digit of each number, starting from ones, up to thousands
      for(int scan = 0; scan < arr.length; scan ++) {
        value = Integer.valueOf(arr[scan]);
        int divide = value / (int) Math.pow(10, position);
        int digit = divide % 10;
        //add the number into the apprpopriate list based on the value of this digit
        digitLists[digit].add(new Integer(arr[scan]), digitLists[digit].size()); 
      }

      //gather the numbers back into the original array, in order from the digit lists
      int index = 0;
      int numObj;
      //look at all ten lists, in ascending order
      for (int digitValue = 0; digitValue <= 9; digitValue ++) {
        //move the numbers from each list into the orginal array
        while(!(digitLists[digitValue].isEmpty())){
          numObj = digitLists[digitValue].remove(digitLists[digitValue].get(0));
          arr[index] = String.valueOf(numObj);
          index ++;
        }
      }
    }
  }
}
