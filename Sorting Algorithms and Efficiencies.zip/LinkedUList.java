/*
An linked implementation of an unordered list, based on ListADT and UnorderedListADT

Written by Andrew Qi
*/

import java.lang.*;
import java.io.*;
import java.util.*;

public class LinkedUList<T> implements UnorderedListADT<T> {

  //Initiate instance variables
  private Node<T> first;
  private Node<T> tail;
  private int count = 0;

  //Constructor
  public LinkedUList() {
    //First node is a dummy node
    Node<T> newNode = new Node<T>();
    this.first = newNode;
    this.tail = null;
  }

  /**********************
   * Clear the list
   ******************/
  public void clear() {
    //Point the first and tail to empty nodes / null
    Node<T> newNode = new Node<T>();
    this.first = newNode;
    this.tail = null;
    this.count = 0;
  }

  /******************
   * Test whether the list is empty
   * @return Whether the list is empty
   ********************/
  public boolean isEmpty() {
    if(this.first.getNext() == null) {
      return true;
    }
    return false;
  }

  /***************
   * Test whether the list contains the given item
   * @return true if the item is in the list
   **********/
  public boolean contains(T item) {
    Node<T> check = this.first.getNext();
    
    //Starting from the node after the dummy, compare the data in each node
    //in the linked list with the given item
    while(check != null) {
      if(check.getData().equals(item)) {
        return true;
      }
      check = check.getNext();
    }

    return false;
  }

  /*********************
   * Get the number of items in the list
   * @return The number of items
   *********************/
  public int size() {
    return this.count;
  }

  /************
  * Adds the given item at a particular index
  ************/
  public void add(T item, int ind) throws IndexOutOfBoundsException {
    if(ind > this.count) {
      throw new IndexOutOfBoundsException("Index out of bounds");
    }

    int track = 0;
    Node<T> beforeAdd = this.first;

    //Find the node to add to (the node before the given index)
    while(track < ind) {
      beforeAdd = beforeAdd.getNext();
      track ++;
    }

    //Create new node with given item and add it after
    //the node found above
    Node<T> addNode = new Node<T>(item);
    addNode.setNext(beforeAdd.getNext());
    beforeAdd.setNext(addNode);

    //Keep track of list count
    this.count ++;

  }

  /***********************
   * Remove the given item from the list
   * @return The item that was removed
   *************************/
  public T remove(T item) {
    
    Node<T> check = this.first.getNext();
    Node<T> prev = this.first;
    boolean found = false;

    //Find the node to be removed and the node before it
    while(check != null && !found) {
      if(item.equals(check.getData())) {
        found = true;
      } 
      else {
        prev = check;
        check = check.getNext();
      }
    }    

    //Link the node before the removed-node to the node after the removed-node
    Node<T> next = check.getNext();
    prev.setNext(next);
    this.count --;

    //Return the data within the node that is removed
    return check.getData();
  }

  /*******************
   * Get the item at the given index, starting at 0
   * @return the item at that index
   *******************/
  public T get(int ind) throws IndexOutOfBoundsException {
    if(ind >= this.count) {
      throw new IndexOutOfBoundsException("Index out of bounds");
    }

    int track = 0;
    Node<T> find = this.first.getNext();

    //Find the node that corresponds to the given index
    while(track != ind) {
      find = find.getNext();
      track ++;
    }

    //Return the data in the node that was found
    return find.getData();
  }
}
