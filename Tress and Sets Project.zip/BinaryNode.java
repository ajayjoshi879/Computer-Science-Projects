/*
* An implementation of a binary node, used to build a binary search tree
* 
* Written by Andrew Qi
*/

import java.lang.*;

public class BinaryNode<T extends Comparable<T>> {

  //Initiate instance variables
  private T data;
  private BinaryNode<T> left;
  private BinaryNode<T> right;

  //Basic methods to access instance variables
  public T getData() { return this.data; }
  public BinaryNode<T> getLeft() { return this.left; }
  public BinaryNode<T> getRight() { return this.right; }

  //Constructor takes a data piece and two binary nodes to assign as children
  public BinaryNode(T item, BinaryNode<T> l, BinaryNode<T> r) {
    this.data = item;
    this.left = l;
    this.right = r;
  }

  //Set the left child
  public void setLeft(BinaryNode<T> newNode) {
    this.left = newNode;
  }

  //Set the right child
  public void setRight(BinaryNode<T> newNode) {
    this.right = newNode;
  }

  /***
  * Removes a binary node that contains a given item.
  * Assists the binary search tree's remove method
  * @param parent The parent of the node examined
  * @param item The data piece to look for
  * @return returns whether the item was successfully removed
  ***/
  public boolean remove(BinaryNode<T> parent, T item) {
    //If the search value is smaller, recurse left
    //If left doesn't exist, the item doesn't exist
    if (item.compareTo(this.data) < 0) {
      if (this.left != null) {
        return this.left.remove(this, item);
      } else {
        return false;
      }
    //If the search value is larger, recurse right
    //If right doesn't exist, the item doesn't exist
    } else if (item.compareTo(this.data) > 0) {
      if (this.right != null) {
        return this.right.remove(this, item);
      } else {
        return false;
      }
    //Found the node we are looking for
    //Reference the parent node to the current node's child(ren)
    } else {
      //Node to be removed has two children
      if (this.right != null && this.left != null) {
        //Replace the node's data with the largest data that is smaller than itself
        this.data = this.left.nextLargest();
        //Remove the node with that piece of data
        this.left.remove(this, this.data);
      //Node to be removed has a left child
      } else if (this.left != null) {
        if (parent.getLeft() == this) {
          parent.setLeft(this.left);
        } else {
          parent.setRight(this.left);
        }
      //Node to be removed has a right child
      } else if (this.right != null) {
        if (parent.getLeft() == this) {
          parent.setLeft(this.right);
        } else {
          parent.setRight(this.right);
        }
      //Node to be removed has no children
      } else {
        if (parent.getLeft() == this) {
          parent.setLeft(null);
        } else {
          parent.setRight(null);
        }
      }
      return true;
    }
  }

  //Find the largest value in a subtree from a given node
  private T nextLargest() {
    //No more larger items
    if (this.right == null) {
      return this.data;
    //Recurse until the rightmost (largest) item is found
    } else {
      return this.right.nextLargest();
    }
  }  
}
