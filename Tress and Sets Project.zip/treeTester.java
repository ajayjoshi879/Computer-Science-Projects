public class treeTester {
	
	public static void main(String[] args) {
		//Create a root node, with a value of 20
		int first = 20;
		BinaryNode<Integer> root = new BinaryNode<Integer>(first, null, null);

		//Create a new binary search tree, with 20 as the value in its root
		BST<Integer> tree = new BST<Integer>(root);
		System.out.println("Testing whether the tree is empty: " + tree.isEmpty() + " (should be false)");
		System.out.println("Adding items into the tree : {10, 5, 1, 25, 30, 21, 50, 3, 17, 46}...");

		tree.add(10);
		tree.add(5);
		tree.add(1);
		tree.add(25);
		tree.add(30);
		tree.add(21);
		tree.add(50);
		tree.add(3);
		tree.add(17);
		tree.add(46);

		System.out.println("Testing whether the tree contains 21: " + tree.contains(21) + " (should be true)");
		System.out.println("Testing whether the tree contains 31: " + tree.contains(31) + " (should be false)");
		System.out.println("Printing the size of the tree (including root): " + tree.getNumNodes() + " (should be 11)");
		System.out.println("Testing whether the tree is empty: " + tree.isEmpty() + " (should be false)");

		ListADT<Integer> treeList = tree.inOrderTraversal();
		System.out.println("Printing selected items of the tree: " + treeList.get(2) + " , " + treeList.get(5) + " , " + treeList.get(7) + " , " + treeList.get(10));
		System.out.println("If the above numbers are printed in ascending order, the tree should be implemented correctly.");

		System.out.println("Testing the tree's remove function...");
		System.out.println("Removing the item 1: " + tree.remove(1) + " (should return true)");
		System.out.println("Removing the item 30: " + tree.remove(30) + " (should return true)");
		System.out.println("Removing the item 20 (the root): " + tree.remove(20) + " (should return true)");
		System.out.println("Removing the item 27 (non-existent): " + tree.remove(27) + " (should return false)");

		System.out.println("Printing the size of the tree: " + tree.getNumNodes() + " (should be 8)");
		System.out.println("Testing whether the tree contains 21: " + tree.contains(21) + " (should be true)");
		System.out.println("Testing whether the tree contains 20: " + tree.contains(20) + " (should be false)");

		treeList = tree.inOrderTraversal();
		System.out.println("Printing items in the tree: (numbers should appear in ascending order)");
		System.out.print(treeList.get(0) + " , " + treeList.get(1) + " , " + treeList.get(2) + " , " + treeList.get(3) + " , ");
		System.out.println(treeList.get(4) + " , " + treeList.get(5) + " , " + treeList.get(6) + " , " + treeList.get(7) + " , ");

		System.out.println("Clearing the tree...");
		tree.clear();
		System.out.println("Checking if tree is empty: " + tree.isEmpty() + " (should be true)");

	}
}