/*
* An implementation of a sorted set, a mathematical represenation of a group of
* sorted numbers, in sorted order, without any duplicate numbers.
*
* Implementation made using a binary search tree.
*
* Written by Andrew Qi
*/

import java.util.*;
import java.lang.*;

public class SortedSet<T extends Comparable<T>> implements SortedSetADT<T> {
	
	//Has a binary search tree as an instance variable
	private BST<T> tree;

	//Constuctor takes a binary search tree
	public SortedSet(BST<T> t) {
		this.tree = t;
	}

	/*******
    * Adds the given item to the set, ignoring duplicates
    * @param item The item to add
    */
   public void add(T item) {
      //Duplicate items are not added to the set
      if (this.tree.contains(item)) {}
      else {
        this.tree.add(item);
      }
   }

   /*********
    * Removes the given item
    * @param item The item to remove
    * @return true if that item was removed, false otherwise
    */
   public boolean remove(T item) {
   		return this.tree.remove(item);
   }

   /*********
    * Checks whether the given item is in the set
    * @param item The item to look for
    * @return true if that item is in the set, false otherwise
    */
   public boolean contains(T item) {
   		return this.tree.contains(item);
   }

   /********
    * Removes all items from the set
    */
   public void clear() {
   		this.tree.clear();
   }

   /*********
    * Gets the number of items in the set
    * @return the number of items in the set
    */
   public int size() {
   		return this.tree.getNumNodes();
   }

   /************
    * Creates a new SortedSet and returns a union of this set and otherSet
    * @param otherSet A SortedSet to combine with this set
    * @return The union of the two sets
    */
   public SortedSetADT<T> union(SortedSetADT<T> otherSet) {
      //Get the items in both sets
      ListADT<T> firstList = this.toList();
      ListADT<T> secondList = otherSet.toList();

      //Create a binary tree, with an arbitrary item as its root, to represent the union set
      BinaryNode<T> root = new BinaryNode<T>(firstList.get(firstList.size() / 2), null, null);
      BST<T> combined = new BST<T>(root);

      //Add all items from the first set, avoiding duplicates
      for (int i = 0; i < firstList.size(); i ++) {
        if (combined.contains(firstList.get(i)) == false) {
          combined.add(firstList.get(i));
        }
      }

      //Add all items from second set that do not duplicate the first set's items
      for (int j = 0; j < secondList.size(); j ++) {
        if (combined.contains(secondList.get(j)) == false) {
          combined.add(secondList.get(j));
        }
      }

      //Create the union set using the tree obtained
      SortedSet<T> union = new SortedSet<T>(combined);
      return union;
   }

   /************
    * Creates a new SortedSet and returns an intersections of this set and otherSet
    * @param otherSet A SortedSet to combine with this set
    * @return The intersection of the two sets
    */
   public SortedSetADT<T> intersect(SortedSetADT<T> otherSet) {
      //Get the items of the two sets
      ListADT<T> firstList = this.toList();
      ListADT<T> secondList = otherSet.toList();

      //Collate all the items that are common to both sets in a list, in order
      ArrayUList<T> common = new ArrayUList<T>();
      int index = 0;
      for (int i = 0; i < firstList.size(); i ++) {
        if (secondList.contains(firstList.get(i))) {
          common.add(firstList.get(i), index);
          index ++;
        }
      }

      //Create binary tree with an arbitrary root from the list of common items
      BinaryNode<T> root = new BinaryNode<T>(common.get(common.size() / 2), null, null);
      BST<T> combined = new BST<T>(root);

      //Add all the intersecting items into the binary search tree
      for (int j = 0; j < common.size(); j ++) {
        if (combined.contains(common.get(j)) == false) {
          combined.add(common.get(j));          
        }
      }

      //Create the intersection set using the tree obtained
      SortedSet<T> intersect = new SortedSet<T>(combined);
      return intersect;
   }

   /************
    * Returns a List of the items in this set, in order.
    * @return A list of the items in this set.
    */
   public ListADT<T> toList() {
   		return this.tree.inOrderTraversal();
   }
}