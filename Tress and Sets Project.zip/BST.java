/*
An implementation of a binary search tree, using binary nodes.

Written by Andrew Qi.
*/

import java.lang.*;

public class BST<T extends Comparable<T>> implements BSTInterface<T> {

  //Initiate instance variables
  private BinaryNode<T> root;
  private int count = 1;

  //Constructor
  public BST(BinaryNode<T> node) {
    this.root = node;
  }

  /*********
  * Checks whether the given item is in the BST
  * @param item The item to look for
  * @return true if that item is in the BST, false otherwise
  */
  public boolean contains(T item) {
    //False if the tree is empty
    if(this.root == null) {
      return false;
    } else {
    //Recursive call to search throughout the tree
      return containsHelper(this.root, item);
    }
  }


  /*********
  * Helps the contains method check whether the given item is in the BST
  * @param item The item to look for
  * @param n The node to look at
  * @return true if that item is in the BST, false otherwise
  */
  private boolean containsHelper(BinaryNode<T> n, T item) {
    //Found the item
    if (item.compareTo(n.getData()) == 0) {
      return true;
    } else if(item.compareTo(n.getData()) < 0) { //item is smaller
      // if left is null, the item doesnt exist
      // otherwise recurse left
      if (n.getLeft() == null) {
        return false;
      } else {
        return containsHelper(n.getLeft(), item);
      }
    } else { //Item is larger
      // if right is null, the item doesnt exist
      // otherwise recurse right
      if (n.getRight() == null) {
        return false;
      } else {
        return containsHelper(n.getRight(), item);
      }
    }
  }

  /*******
    * Adds the given item to the BST
    * @param item The item to add
    */
  public void add(T item) {
    //Add the item as the root if the tree is empty
    if(this.root == null) {
      this.root = new BinaryNode<T>(item, null, null);
    } else {
    //Make recursive calls to find where to add the item
      addHelper(root, item);
    }
    this.count ++;
  }

  private void addHelper(BinaryNode<T> n, T item) {
    if(item.compareTo(n.getData()) <= 0) { //Item is smaller
      // if left is null, add the item at left
      // otherwise recurse left
      if (n.getLeft() == null) {
        BinaryNode<T> newNode = new BinaryNode<T>(item, null, null);
        n.setLeft(newNode);
      } else {
        addHelper(n.getLeft(), item);
      }
    } else { //Item is larger
      // if right is null, add the item at right
      // otherwise recurse right
      if (n.getRight() == null) {
        BinaryNode<T> newNode = new BinaryNode<T>(item, null, null);
        n.setRight(newNode);
      } else {
        addHelper(n.getRight(), item);
      }
    }
  }

  /*********
    * Removes the given item
    * @param item The item to remove
    * @return true if that item was removed, false otherwise
    */
  public boolean remove(T item) {
    //Can't remove from empty tree
    if (this.root == null) {
      return false;
    } else {
      this.count --;
      //Remove the root if it is the item
      if (item.compareTo(root.getData()) == 0) {
        //Create temporary root to find the original root's replacement
        BinaryNode<T> tempRoot = new BinaryNode<T>(null, this.root, null);
        boolean result = this.root.remove(tempRoot, item);
        //Replace root with the next largest number
        this.root = tempRoot.getLeft();
        return result;
      } else {
        //Recurse to find and remove the item
        return root.remove(null, item);
      }
    }
  }

  /*********
    * Gets the number of items in the BST
    * @return the number of items in the BST
    */
  public int getNumNodes() {
    ListADT<T> treeList = this.inOrderTraversal();
    return treeList.size();
  }

  /********
    * Removes all items from the BST
    */
  public void clear() {
    this.root = null;    
    this.count = 0;
  }

  /*********
    * Checks whether the BST is empty
    * @return true if the BST is empty
    */
  public boolean isEmpty() {
    if (this.count == 0) {
      return true;
    }
    return false;
  }

  /**********
    * Return an array that contains all the items in this BST in an in-order traversal
    * @return the array
    */
  public ListADT<T> inOrderTraversal() {
    //Traverses and obtains the tree's items in an list, in reverse order
    ArrayUList<T> rTreeList = new ArrayUList<T>();
    traversalHelper(root, rTreeList);

    //Reverses the items' order back into the correct order
    ArrayUList<T> treeList = new ArrayUList<T>();
    int location = 0;
    for (int i = rTreeList.size() - 1; i >= 0; i --) {
      treeList.add(rTreeList.get(i), location);
      location ++;
    }

    return treeList;
  }

  /**********
    * Helps inOrderTraversal by using recursion to traverse through the tree in order.
    * Adds items into an unordered array list. Because each item is added at index 0,
    * the final array will contain the tree items in reverse order.
    */
  private void traversalHelper(BinaryNode<T> node, ArrayUList<T> list) {
    //Done traversing through the tree
    if (node == null) {
      return;
    }

    //traverses through the tree in order, using recursion
    traversalHelper(node.getLeft(), list);
    //adds the tree's items into a list
    list.add(node.getData(), 0);
    traversalHelper(node.getRight(), list);
  }
}
