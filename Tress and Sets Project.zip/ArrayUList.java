/*
An array implementation of an unordered list.

Written by Andrew Qi
*/

import java.io.*;
import java.lang.*;
import java.util.*;

public class ArrayUList<T> implements UnorderedListADT<T> {
	
	//Initiate instance variables
	private final static int NOT_FOUND = -1;
	private int rear;
	private T[] list;

	/******
	* Constructor
	*****/
	public ArrayUList() {
		this.rear = 0;
		this.list = (T[]) (new Object[100]);
	}

	/***********************
   	* Remove the given item from the list
   	* @return The item that was removed
   	*************************/
	public T remove(T item) {
		//Find the index of the given element
		int index = 0;
		int location = NOT_FOUND;
		//Find the index of the item to be removed
		while(location == NOT_FOUND && index < this.rear) {
			if(this.list[index].equals(item)) {
				location = index;
			}
			else {
				index ++;
			}
		}

		//Throw a warning if the given item is not found in the list
		if(location == NOT_FOUND) {
			throw new NoSuchElementException();
		}

		T result = list[location];
		this.rear --;

		//Shift the appropriate elements in the list after removing the given item
		for(int scan = location; scan < this.rear; scan ++) {
			this.list[scan] = this.list[scan + 1];
		}

		this.list[rear] = null;
		return result;
	}

	/***************
  	* Test whether the list contains the given item, using binary search
   	* @return true if the item is in the list
   	**********/
	public boolean contains(T item) {
		for (int i = 0; i < this.rear; i ++) {
			if (this.list[i].equals(item)) {
				return true;
			}
		}

		return false;
	}

	/**************
	* Add an item into the ordered list, at the appropriate location
	*********/
	public void add(T item, int index) {

		if(index > this.rear) {
      		throw new IndexOutOfBoundsException("Index out of bounds");
    	}

		//Simply add the item if the list is empty and there is nothing to compare
		if(this.rear == 0) {
			this.list[0] = item;
			this.rear ++;
		} else {
			//Expand the array if it is full
			if(this.rear == this.list.length) {
				T[] newArray = (T[]) (new Object[this.list.length * 2]);
				for(int i = 0; i < this.rear; i ++) {
					newArray[i] = this.list[i];
				}
				this.list = newArray;
			}

			//from the given index, shift existing elements up one
			for(int shift = this.rear; shift > index; shift--) {
				list[shift] = list[shift - 1];
			}

			//insert element at given index
			this.list[index] = item;
			this.rear ++;
		}
		
	}

	/*******************
   	* Get the item at the given index, starting at 0
   	* @return the item at that index
   	*******************/
	public T get(int index) {
		if(index >= this.rear) {
			throw new IndexOutOfBoundsException();
		}

		return this.list[index];
	}

	/******************
   	* Test whether the list is empty
   	* @return Whether the list is empty
   	********************/
	public boolean isEmpty() {
		if(this.list[0] == null) {
			return true;
		}

		return false;
	}

	/*********************
   	* Get the number of items in the list
   	* @return The number of items
   	*********************/
	public int size() {
		return this.rear;
	}		

	/**********************
   	* Clear the list
   	******************/
	public void clear() {
		this.list = (T[]) (new Object[100]);
		this.rear = 0;
	}
}