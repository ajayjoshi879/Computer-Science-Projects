/*
A class that tests the functioning of the SortedSet class.

Written by Andrew Qi
*/

public class setTester {
	
	public static void main(String[] args) {
		//Iniate two roots
		BinaryNode<Integer> root1 = new BinaryNode<Integer>(42, null, null);
		BinaryNode<Integer> root2 = new BinaryNode<Integer>(42, null, null);

		//Create two trees with the two roots created above
		BST<Integer> tree1 = new BST<Integer>(root1);
		BST<Integer> tree2 = new BST<Integer>(root2);

		//Add numbers into the two trees
		for (int i = 1; i < 20; i ++) {
			tree1.add(i * 5);
		}

		for (int j = 1; j < 10; j ++) {
			tree2.add(j * 10);
		}

		//Create two sets using the two trees
		SortedSet<Integer> set1 = new SortedSet<Integer>(tree1);
		SortedSet<Integer> set2 = new SortedSet<Integer>(tree2);

		//Testing the toList method of the SortedSet
		System.out.print("Printing the items of set1: ");
		ListADT<Integer> set1List = set1.toList();
		for (int k = 0; k < set1List.size(); k ++) {
			System.out.print(set1List.get(k) + " , ");
		}
		System.out.println();

		//Testing the SortedSet's add and size methods
		System.out.println("Printing the size of the set: " + set1.size() + " (should be 20)");
		System.out.println("Adding duplicate item...");
		set1.add(42);
		System.out.println("Printing set size: " + set1.size() + " (if size is still 20, duplicate item was successfully not added)");

		//Testing the SortedSet's contains method
		System.out.println("Checking whether the set contains 67: " + set1.contains(67) + " (should be false)");
		System.out.println("Adding the number 67 to the list");
		set1.add(67);
		System.out.println("Checking whether the set now contains 67: " + set1.contains(67) + " (should be true)");

		//Testing the SortedSet's remove method
		System.out.println("Removing the value 42: " + set1.remove(42) + " (should be true)");
		System.out.println("Removing the value 0: " + set1.remove(0) + " (should be false)");

		//Print the numbers in the second set
		System.out.print("Printing the items of set2: ");
		ListADT<Integer> set2List = set2.toList();
		for (int k = 0; k < set2List.size(); k ++) {
			System.out.print(set2List.get(k) + " , ");
		}
		System.out.println();

		//Testing the SortedSet's union method
		SortedSetADT<Integer> unionSet = set1.union(set2);
		ListADT<Integer> union = unionSet.toList();
		System.out.print("Finding union of set1 and set2: ");
		for (int k = 0; k < union.size(); k ++) {
			System.out.print(union.get(k) + " , ");
		}
		System.out.println();

		//Testing the SortedSet's intersection method
		SortedSetADT<Integer> intersectSet = set1.intersect(set2);
		ListADT<Integer> intersect = intersectSet.toList();
		System.out.print("Finding intersect of set1 and set2: ");
		for (int k = 0; k < intersect.size(); k ++) {
			System.out.print(intersect.get(k) + " , ");
		}
		System.out.println();

		//Testing the SortedSet's clear method
		System.out.println("Clearing set1...");
		set1.clear();
		System.out.println("Size of set1: " + set1.size() + " (should be 0)");
	}
}